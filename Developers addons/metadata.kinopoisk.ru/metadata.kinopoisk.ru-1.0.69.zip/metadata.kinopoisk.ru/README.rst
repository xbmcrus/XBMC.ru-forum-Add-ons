Kinopoisk.ru movie scraper for XBMC
===================================

Description
-----------

Download Movie information from www.kinopoisk.ru

Supports NfoUrl.

Supported tags::

  title
  originaltitle
  rating
  year
  top250
  votes
  outline and plot (same content)
  tagline
  runtime
  thumb
  fanart (from themoviedb.org)
  mpaa
  id
  genre
  country
  credits
  director
  studio
  trailer
  actor
