import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon

settings = xbmcaddon.Addon(id='script.module.translit')
version = "2.0.1"
plugin = "Translit-" + version
